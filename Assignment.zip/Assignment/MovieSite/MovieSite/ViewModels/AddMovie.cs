﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.ViewModels
{
    public class AddMovie
    {
        [Required]
        public string Name { get; set; }

        [Required]
        public int YearOfRelease { get; set; }

        [Required]
        public string Plot { get; set; }

        [Required]
        public IFormFile Image { get; set; }

        //      [Required]
        //      public string ActorName { get; set; }

        [Required]
        public string ProducerName { get; set; }

    }
}
