﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.Models
{
    public interface IActorsRepository
    {
       
        IEnumerable<Actors> ListActors();
        //Movies Add(Movies newmovie);
        //Movies Edit(Movies moviechange);
        //Movies Delete(int id);
    }
}
