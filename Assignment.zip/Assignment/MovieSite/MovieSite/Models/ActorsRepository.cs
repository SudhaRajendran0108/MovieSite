﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using static MovieSite.Models.Actors;

namespace MovieSite.Models
{
    public class ActorsRepository : IActorsRepository
    {
        private readonly string connectionstring = String.Empty;
        private readonly SqlConnection conn = null;
        private List<Actors> _actors;
       
        public ActorsRepository()
        {
            _actors = new List<Actors>();
            connectionstring = "Server=Atos-BizTalk-VM ; Database=MovieSiteDB ; Integrated Security=SSPI";
            conn = new SqlConnection(connectionstring);

        }

        public IEnumerable<Actors> ListActors()
        {
            SqlCommand cmd = new SqlCommand("getallactordetailsprocedure", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Actors actor = new Actors();
                    actor.Id = Convert.ToInt32(rdr.GetValue(0).ToString());
                    actor.Name = rdr.GetValue(1).ToString();
                    actor.Sex = (ActorSex)Enum.Parse(typeof(ActorSex), rdr.GetValue(2).ToString());
                    actor.DOB = Convert.ToDateTime(rdr.GetValue(3).ToString());
                    actor.Bio = rdr.GetValue(4).ToString();
                    actor.Image = rdr.GetValue(5).ToString();

                    _actors.Add(actor);
                }
            }
            conn.Close();
            return _actors;
        }
    }
}
