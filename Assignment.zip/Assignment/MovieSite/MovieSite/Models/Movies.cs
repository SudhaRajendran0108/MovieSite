﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.Models
{
    public class Movies
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public int YearOfRelease { get; set; }

        public string Plot { get; set; }
        
       public string Image { get; set; }
       
    }
}
