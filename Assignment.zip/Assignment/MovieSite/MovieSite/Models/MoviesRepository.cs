﻿using Microsoft.AspNetCore.Mvc;
using MovieSite.ViewModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace MovieSite.Models
{
    public class MoviesRepository : IMoviesRepository
    {
        private readonly string connectionstring = String.Empty;
        private readonly SqlConnection conn = null;
        private List<Movies> _movies;
        private List<MovieDetails> _details;
        private readonly ProducersRepository _producersrepository;

        public MoviesRepository()
        {
            _producersrepository = new ProducersRepository();
            _movies = new List<Movies>();
            _details = new List<MovieDetails>();
            connectionstring = "Server=Atos-BizTalk-VM ; Database=MovieSiteDB ; Integrated Security=SSPI";
            conn = new SqlConnection(connectionstring);

        }
 
        public IEnumerable<Movies> ListMovies()
        {
            
            SqlCommand cmd = new SqlCommand("listmovieprocedure", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            conn.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    Movies movie = new Movies();
                    movie.Id = Convert.ToInt32(rdr.GetValue(0).ToString());
                    movie.Name = rdr.GetValue(1).ToString();
                    movie.YearOfRelease = Convert.ToInt32(rdr.GetValue(2).ToString());
                    movie.Plot = rdr.GetValue(3).ToString();
                    movie.Image = rdr.GetValue(4).ToString();

                    _movies.Add(movie);
                }
            }
            conn.Close();
            return _movies;
        }

        public IEnumerable<MovieDetails> MovieDetails(int id)
        {
            MovieDetails _moviedetail = new MovieDetails();
            SqlCommand cmd = new SqlCommand("getdetailsmovieprocedure", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p1 = cmd.Parameters.Add("@MovieId", SqlDbType.VarChar, 5);
            p1.Value = id;
            conn.Open();
            SqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {

                    _moviedetail.Id = Convert.ToInt32(rdr.GetValue(0).ToString());
                    _moviedetail.MovieName = rdr.GetValue(1).ToString();
                    _moviedetail.YearOfRelease = Convert.ToInt32(rdr.GetValue(2).ToString());
                    _moviedetail.Plot = rdr.GetValue(3).ToString();
                    _moviedetail.ProducerName = rdr.GetValue(4).ToString();
                    _moviedetail.Image = rdr.GetValue(5).ToString();
                    _moviedetail.ActorName = rdr.GetValue(6).ToString();
                    

                    _details.Add(_moviedetail);
                }
            }
           
            conn.Close();
           
            return _details;
          
        }
        
        public bool Add(AddMovieDetails moviedata)
        {

            SqlCommand cmd = new SqlCommand("addmovieprocedure", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter p1 = cmd.Parameters.Add("@MovieName", SqlDbType.VarChar, 50);
            SqlParameter p2 = cmd.Parameters.Add("@YearOfRelease", SqlDbType.Int);
            SqlParameter p3 = cmd.Parameters.Add("@Plot", SqlDbType.VarChar, 500);
            SqlParameter p4 = cmd.Parameters.Add("@ImagePath", SqlDbType.VarChar, 100);
            SqlParameter p5 = cmd.Parameters.Add("@ProducerName", SqlDbType.VarChar, 50);

            p1.Value = moviedata.Name;
            p2.Value = moviedata.YearOfRelease;
            p3.Value = moviedata.Plot;
            p4.Value = moviedata.Image;
            p5.Value = moviedata.ProducerName;
            conn.Open();
            int count = cmd.ExecuteNonQuery();
            if (count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public Movies Edit(Movies moviechange)
        {
            throw new NotImplementedException();
        }

        public Movies Delete(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Producers> getproducername()
        {
            return _producersrepository.getproducername();
        }
    }
}
